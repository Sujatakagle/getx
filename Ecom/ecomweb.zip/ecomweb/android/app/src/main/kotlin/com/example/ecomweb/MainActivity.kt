package com.example.ecomweb

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
